#include<stdio.h>
int n1, n2, sueldo;

int main()
{
    printf("ingrese horas trabajadas:");
    scanf("%d", &n1);
    printf("ingrese valor hora:");
    scanf("%d", &n2);
    sueldo=n1*n2;
    printf("su sueldo es:%d", sueldo);
    return 0;
}