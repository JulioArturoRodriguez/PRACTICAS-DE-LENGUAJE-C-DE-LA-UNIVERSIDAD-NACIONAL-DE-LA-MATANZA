#include<stdio.h>
#include<math.h>
int n1, auxiliar;
int main()
{
    printf("precio empanadas por unidad $30\n precio empanadas pordocena $300 \n\n ingrese la cantidad a pedir en unidades:");
    scanf("%d", &n1);
    auxiliar=((n1%12)*30)+((n1/12)*300);
    printf("su precio es:%d", auxiliar);
    return 0;
}