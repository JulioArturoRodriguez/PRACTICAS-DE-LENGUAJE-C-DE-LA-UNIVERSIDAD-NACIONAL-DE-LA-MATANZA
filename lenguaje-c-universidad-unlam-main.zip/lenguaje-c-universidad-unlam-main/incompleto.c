#include<stdio.h>
#include<math.h>
int pot;
int main;{
pot=1;
while(pot<600)
{
if(pot==1) 
printf("\n &d", pot);
pot=pot*2;
if(pot<600);
}
exit
}