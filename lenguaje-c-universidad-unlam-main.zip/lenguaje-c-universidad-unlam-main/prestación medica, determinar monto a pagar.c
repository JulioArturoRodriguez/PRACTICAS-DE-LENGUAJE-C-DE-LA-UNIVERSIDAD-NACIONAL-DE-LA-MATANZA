#include<stdio.h>
#include<conio.h>
char codigo;
int auxiliar, n1, auxiliar2, auxiliar3, auxiliar4, auxiliar5;
int main()
{
    printf("ingrese el codigo del paciente:A,D,F,M,T\n");
    scanf("%c", &codigo);
    printf("ingrese el numero de historia del paciente:\n");
    scanf("%d", &n1);
    auxiliar=20;
    auxiliar2=40;
    auxiliar3=60;
    auxiliar4=150;
    auxiliar5=150;
    codigo=toupper(codigo);
    switch (codigo)
    {
    case 'A' : 
    printf("codigo A\ndebe pagar:%d\nsu numero de paciente es:%d", auxiliar, n1);
    break;
    case 'D' :
     printf("codigo D\ndebe pagar:%d\nsu numero de paciente%d", auxiliar2, n1);
    break;
    case 'F' :
     printf("codigo F\ndebe pagar:%d\nsu numero de paciente:%d", auxiliar3, n1);
    break;
    case 'M' : 
    printf("codigo M\ndebe pagar:%d\nsu numero de paciente:%d", auxiliar4, n1);
    break;
    case 'T' : 
    printf("codigo T\ndebe pagar:%d\nsu numero de paciente:%d", auxiliar5, n1);
    break;
    }
    getchar();
    return 0; 
}