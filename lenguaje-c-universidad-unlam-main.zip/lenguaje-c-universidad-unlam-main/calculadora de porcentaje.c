#include<stdio.h>
float n1, n2, porcentaje;

int main()
{
    printf("tener en cuenta que esta calculadora saca el porcentaje con decimales\n\n");
    printf("ingresar un numero para sacar porcentajes:\n");
    scanf("%f", &n1);
    printf("ingrese el porcentaje a calcular:");
    scanf("%f", &n2);
    porcentaje=n1*n2/100;
    printf("su porcentaje es:%f", porcentaje);
    return 0;
}