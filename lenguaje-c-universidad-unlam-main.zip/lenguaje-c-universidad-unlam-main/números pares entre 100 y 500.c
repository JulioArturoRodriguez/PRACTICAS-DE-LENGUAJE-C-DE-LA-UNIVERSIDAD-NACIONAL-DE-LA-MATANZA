#include<stdio.h>
#include<conio.h>
int i, multiplicasion, suma;
int main()
{
    for(i=100;i<=500; i++)
    {
    if(i%2==0)
    {
    printf("%d\n", i);
    }}
    return 0;
}