#include<stdio.h>
#include<math.h>
int numero, orden, menor;
int main()
{
 printf("este programa saca el numero mas chico y su orden\n\n\n");
    printf("ingrese un numero:\n");
    scanf("%d", &numero);
    
     menor=numero;
     orden=1;
    
     printf("ingrese un segundo numero:\n");
     scanf("%d", &numero);
    
       if(numero<menor)
       menor=numero;
       orden=2;
      

      printf("ingrese un segundo numero:\n");
     scanf("%d", &numero);
    
       if(numero<menor)
       menor=numero;
       orden=3;
       

      printf("ingrese un segundo numero:\n");
     scanf("%d", &numero);
    
  

       if(numero<menor)
       menor=numero;
       orden=4;
       
      printf("el menor es:%d\n", menor);
      printf("el orden es:%d", orden);
    
  return 0;
}