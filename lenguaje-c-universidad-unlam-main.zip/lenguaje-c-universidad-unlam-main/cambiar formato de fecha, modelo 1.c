#include<stdio.h>
#include<time.h>
int n1,n2,n3;
int main()
{
    printf("la presente aplicacion cambia el formato de las fechas");
    printf("ingrese el dia:");
    scanf("%d", &n1);
    printf("ingrese el mes: \n");
    scanf("%d", &n2);
    printf("ingrese el año: \n");
    scanf("%d", &n3);
    printf("año%d mes%d año%d", n3, n2, n1);
    return 0;
}