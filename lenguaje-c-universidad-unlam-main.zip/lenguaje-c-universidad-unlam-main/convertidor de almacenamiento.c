#include<stdio.h>
int n1, mib, gib, tib;
int main()
{
    printf("ingrese un la cantidad de kibibyte a convertir en mib, gib y tib:");
    scanf("%d", &n1);
    mib=n1/1024;
    gib=n1/1048576;
    tib=n1/1073741824;
    printf("el espacio en kib es:%d\n", n1);
    printf("el espacio en mib es:%d\n", mib);
    printf("el espacio en gib es:%d\n", gib);
    printf("el espacio en tib es:%d", tib);
     return 0;
}