#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
typedef struct
{
char nombre[10];
int telefono;
}sContacto;
int main()
{
    sContacto contacto;

    FILE*arch;
    arch=fopen("agenda.dat","ab");
    if(arch==NULL)
    {
    printf("error al abrir el archivo");
    getch();
    exit(1);
    }
    printf("ingrese el nombre del nuevo contacto:");
    scanf("%s", &contacto.nombre);
    while(strcmp(contacto.nombre, "FIN")!=0)
    {
    printf("ingrese el telefono:");
    scanf("%d", &contacto.telefono);
    fwrite(&contacto,sizeof(sContacto),1, arch);
   printf("ingrese el nombre del nuevo contacto:");
    scanf("%s", &contacto.nombre);
    
     }
    fclose(arch);
    getch();
    return 0;
}