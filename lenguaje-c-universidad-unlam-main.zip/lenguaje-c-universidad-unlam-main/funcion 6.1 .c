#include<stdio.h>
void opciones();
int main()
{
    opciones();
    return 0;
}
void opciones()

{
int num1, num2, num3;
printf("ingrese un numero:");
scanf("%d", &num1);
printf("\n ingrese un segundo numero:");
scanf("%d", &num2);
printf("\n numero 1:%d \t numero 2:%d \n ", num1, num2);
printf("1) sumar\n");
printf("2) restar\n");
printf("3) multiplicar\n");
printf("4) dividir\n");
printf("5) ingresar nuevo numero\n");
printf("eliga opcion");
scanf("%d",&num3);
switch(num3)
{
case 1:
printf("1) sumar");
break;
case 2:
printf("2) restar");
break;
case 3:
printf("3) multiplicar");
break;
case 4:
printf("4) dividir");
break;
case 5:
printf("5) ingresar nuevo numero");
break;
default:
printf("error");
}}