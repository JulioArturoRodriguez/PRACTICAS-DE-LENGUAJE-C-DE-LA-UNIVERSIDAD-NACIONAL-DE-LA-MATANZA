#include<stdio.h>
int n1, n2, auxiliar;
int main()
{
    printf("ingrese la cantidad de horas trabajadas: \n");
    scanf("%d", &n1);
    printf("ingrese el valor hora:\n");
    scanf("%d", &n2);
    if(n1>50 && n1<500)
    {
    auxiliar=(n1*n2)+500;
    }
    if(n1>150)
    {
    auxiliar=(n1*n2)+1000;
    }
    if(n1<50)
    {
    auxiliar=(n1*n2);
    }
    else
    {
    printf("hubo un error");
    }
    printf("su resultado es:%d", auxiliar);
    return 0;
}