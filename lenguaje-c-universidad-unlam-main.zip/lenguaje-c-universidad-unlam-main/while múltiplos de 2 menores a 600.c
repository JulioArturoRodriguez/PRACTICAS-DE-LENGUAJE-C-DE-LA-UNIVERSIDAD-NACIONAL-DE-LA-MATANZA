#include <stdio.h>
#include <stdlib.h>
int main ()
{
int pot;
pot=1;
while (pot<600)
{
if (pot==1)
 printf ("\n %d", pot) ;
pot=pot*2;
if (pot<600) 
printf ("\n %d", pot);
}
return 0;
}