#include<stdio.h>
#include<conio.h>
int i, multiplicasion, suma;
int main()
{
    for(i=50;i<=100; i++)
    {
    if(i%5==0)
    {
    printf("%d\n", i);
    }}
    return 0;
}