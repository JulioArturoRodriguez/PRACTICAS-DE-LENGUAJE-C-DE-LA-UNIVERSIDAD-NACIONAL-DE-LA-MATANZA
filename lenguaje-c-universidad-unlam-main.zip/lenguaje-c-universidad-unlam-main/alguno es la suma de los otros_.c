#include<stdio.h>
#include<math.h>
int n1, n2, n3;
int main()
{
    printf("ingrese tres numeros enteros, uno a la vez\n");
    printf("ingrese un numero:\n\n");
    scanf("%d", &n1);
    printf ("ingrese un numero:\n\n");
    scanf("%d", &n2);
    printf("ingrese un numero entero:\n\n");
    scanf("%d", &n3);
    if(n1==(n2+n3))
    printf("el primer numero es igual a la suma de los otros, siendo este:%d", n1);
    if(n2==(n1+n3))
    printf("el segundo numero es igual a la suma de los otros dos siendo este:%d", n2);
   if(n3==(n1+n2))
    printf("el tercer numero es igual a la suma de los otros dos, siendo este:%d", n3);
   else
   printf("hubo un error");
     return 0;
}