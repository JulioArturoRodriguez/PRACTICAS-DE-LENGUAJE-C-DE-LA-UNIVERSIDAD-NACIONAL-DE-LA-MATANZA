#include<stdio.h>
#include<conio.h>
#include<string.h>

struct producto
{
int codigo;
float precio;
char nombre[10];
};
int main()
{
struct producto producto1;
printf("ingrese el codigo:");
scanf("%d", &producto1.codigo);
system("clear");
printf("ingrese el precio:");
scanf("%f", &producto1.precio);
system("clear");
printf("ingresar nombre:");
scanf("%s", producto1.nombre);
system("clear");
printf("\t\tdatos del producto\n");
printf("************************************************************************************************************");
printf("codigo: \t precio: \t nombre: ");
printf("\n%5d \t\t %6f \t %6s", producto1.codigo, producto1.precio, producto1.nombre);
   
    return 0;
}