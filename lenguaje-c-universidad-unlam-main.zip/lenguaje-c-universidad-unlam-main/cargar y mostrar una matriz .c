#include<stdio.h>
#include<stdlib.h>
int intento[3][5];
int i, j;
int main()
{
    for(i=0;i<5;i++)
    for(j=0;j<3;j++)
    {
    printf("ingrese un numero entero[%d, %d]:", i, j);
    scanf("%d", &intento[i][j]);
    system("clear");
    }
    for(i=0;i<5;i++)
    {
    printf("\n fila\t");
    for(j=0;j<3;j++)
    {
    printf("%d\t", intento[i][j]);
    }} 
    system("pause");
    
    return 0;
}