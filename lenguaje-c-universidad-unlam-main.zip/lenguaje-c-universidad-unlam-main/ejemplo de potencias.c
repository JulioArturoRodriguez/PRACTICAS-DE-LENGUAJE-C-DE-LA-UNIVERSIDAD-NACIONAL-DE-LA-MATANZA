#include<stdio.h>
#include<math.h>
int a, b, res;

int main()
{
    printf("ingresar un valor:");
    scanf("%d", &a);
    printf("\n ingresar la potencia:");
    scanf("%d", &b);
    res=pow(a,b);
    printf("\n resultado:%d", res);
    return 0;
}