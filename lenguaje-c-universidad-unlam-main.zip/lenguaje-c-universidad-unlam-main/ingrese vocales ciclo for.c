#include<stdio.h>
int main()
 {
 int cont_voc=0, n;
char letra;
 printf("Ingresar 100 letras: \n");
 for(n=1; n<=100;n++)
{ fflush(stdin);
scanf("%c",&letra);
letra=tolower(letra); 
if(letra=='a'||
letra=='e'|| 
letra=='i'|| 
letra=='o'||
 letra=='u')
cont_voc++; }
 if (cont_voc>0) 
printf("\n La cantidad de vocales ingresadas es de :%d \n\n ", cont_voc);
else printf("\n No se ingresaron vocales"); 
return 0;
}