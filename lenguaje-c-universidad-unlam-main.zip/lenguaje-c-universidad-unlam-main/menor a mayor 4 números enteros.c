#include<stdio.h>
#include<math.h>
int n1, n2, n3, n4;
int main()
{
    printf("ingrese un numero:\n");
    scanf("%d", &n1);
    printf("ingrese un numero:\n");
    scanf("%d", &n2);
    printf("ingrese un numero:\n");
    scanf("%d", &n3);
    printf("ingrese un numero:\n");
    scanf("%d", &n4);
  if(n1<n2&& n2<n3&&n3<n4)
    printf("el numero mas chico es:%d\n", n1);
    if(n1<n3 && n3<n4 && n4<n2)
       printf("el numero mas chico es:%d\n", n1);
          if(n1<n4 && n4<n3 && n3<n2)
          printf("el numero mas chico es:%d\n", n1);
            if(n1<n4 && n4<n2 && n2<n3)
            printf("el numero mas chico es:%d\n", n1);
              if(n2<n3 && n3<n4 && n4<n1)
              printf("el numero mas chico es:%d\n", n2);
                if(n2<n1 && n1<3 && n3<n4)
                printf("el numero mas chico es:%d\n", n2);
                  if(n2<n4 && n4<n3 && n3<n1)
                  printf("el numero mas chico es:%d\n", n2);
                    if(n3<n4 && n4<n1 && n1<n2)
                    printf("el numero mas chico es%d\n", n3);
                      if(n3<n2 && n2<n4 && n4<n1)
                      printf("el numero mas chico es:%d\n", n3);
                        if(n3<n1 && n1<n4 && n4<n2)
                        printf("el numero mas chico es:%d\n", n3);
                          if(n4<n1 && n1<n2&& n2<n3)
                          printf("el numero mas chico es:%d\n", n4);
                             if(n4<n3 && n3<n2 && n2<n1)
                             printf("el numero mas chico es:%d\n", n4);
                               if(n4<n2 && n2<n3 && n3<n1)
                               printf("el numero mas chico es:%d\n", n4);
                                  if(n1<n2 && n1<3 && n3>n4)
                                  printf("el numero mas chico es:%d\n",n1);
                                    if(n3<n4 && n4<n2 && n4<n1)
                                    printf("el numero mas chico es:%d\n",n3);
                                      if(n1<n2 && n1>n3 && n1<n4)
                                         printf("el primer numero es:%d\n", n1);
else

  if(n1>n2 && n1<n3 && n1<n4)
  printf("el siguiente es:%d\n", n1);
    if(n1>n3 && n1<n2 && n1<n4)
    printf("el segundo es:%d\n", n1);
      if(n1>n4 && n1<2 && n1<n3)
      printf("el segundo es:%d\n", n1);
        if(n2>n1 && n2<n3 && n2<n4)
        printf("el numero dos en orden creciente es:%d\n", n2);
          if(n2>n3 && n2<n1 && n2<n4)
          printf("le sigue el:%d\n", n2);
            if(n2>n4 && n2<n3 && n2<n1)
            printf("luego:%d\n", n2);
              if(n3>n1 && n3<n2 && n3<n4)
              printf("le sigue:%d\n", n3);
                 if(n3>n2 && n3<n1 && n3<n4)
                  printf("luego:%d\n",n3);
                    if(n3>n4 && n3<n2 && n3<n1)
                    printf("despues:%d\n",n3);
                      if(n4>n1 && n4<n2 && n4<n3)
                      printf("despues:%d\n", n4);
                        if(n4>n2 && n4<n3 && n4<n1)
                        printf("luego:%d\n", n4);
                          if(n4>n3 && n4<n2 && n4<n1)
                          printf("despues:%d\n", n4);
   else 
   if(n1>n2 && n1>n3 && n1<n4)
     printf("el tercer numero es:%d\n", n1);
       if(n1>n3 && n1>n4 && n1<n3)
       printf("el tercer numero es:%d\n",n1);
        if(n1>n4 && n1>n3 && n1<n2)
        printf("el tercer numero es:%d\n", n1);
         if(n2>n1 && n2>n3 && n2<n4)
         printf("el tercer numero es:%d\n", n2);
          if(n2>n3 && n2>n4 && n2<n3)
          printf("el tercer numero es:%d\n",n2);
           if(n2>n4 && n2>n3 && n2<n2)
           printf("el tercer numero es:%d\n", n2);
            if(n3>n1 && n3>n1 && n3<n4)
            printf("el tercer numero es:%d\n", n3);
             if(n3>n1 && n3>n4 && n3<n2)
             printf("el tercer numero es:%d\n",n3);
              if(n3>n4 && n3>n1 && n3<n2)
              printf("el tercer numero es:%d\n", n3);
               if(n4>n1 && n4>n3 && n4<n3)
               printf("el tercer numero es:%d\n", n4);
                if(n4>n3 && n4>n2 && n4<n1)
                printf("el tercer numero es:%d\n",n4);
                  if(n4>n1 && n4>n3 && n4<n2)
                  printf("el tercer numero es:%d\n", n4);
                    if(n1>n2 && n2>n3 && n3>n4)
                    printf("el tercer numero es:%d\n",n2);
  
 else 
if(n1>n2 && n1>n3 && n1<n4)
     printf("el tercer numero es:%d\n", n4);
       if(n1>n3 && n1>n4 && n1<n3)
       printf("el tercer numero es:%d\n",n3);
        if(n1>n4 && n1>n3 && n1<n2)
        printf("el tercer numero es:%d\n", n2);
         if(n2>n1 && n2>n3 && n2<n4)
         printf("el tercer numero es:%d\n", n4);
          if(n2>n3 && n2>n4 && n2<n3)
          printf("el tercer numero es:%d\n",n3);
           if(n2>n4 && n2>n3 && n2<n1)
           printf("el tercer numero es:%d\n", n1);
            if(n3>n1 && n3>n1 && n3<n4)
            printf("el tercer numero es:%d\n", n4);
             if(n3>n1 && n3>n4 && n3<n2)
             printf("el tercer numero es:%d\n",n3);
              if(n3>n4 && n3>n1 && n3<n2)
              printf("el tercer numero es:%d\n", n2);
               if(n4>n1 && n4>n3 && n4<n3)
               printf("el tercer numero es:%d\n", n3);
                if(n4>n3 && n4>n2 && n4<n1)
                printf("el tercer numero es:%d\n",n1);
                  if(n4>n1 && n4>n3 && n4<n2)
                  printf("el tercer numero es:%d\n", n2);
       
 
   
    return 0;
}