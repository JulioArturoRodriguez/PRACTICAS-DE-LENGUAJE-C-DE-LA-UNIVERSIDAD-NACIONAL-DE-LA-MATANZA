#include<stdio.h>
int i, j, aux;
int vec[10]={9,8,7,6,5,4,88,33,99,90};
int main()
{
   for(i=0;i<10;i++){
   for(j=0;j<10;j++){
  if(vec[j]>vec[j+1]){
   aux=vec[j];
   vec[j]=vec[j+1];
   vec[j+1]=aux;
}
}
}
for(i=0;i<10;i++)
   printf("\n su numero es:%d", vec[i]);
    return 0;
}