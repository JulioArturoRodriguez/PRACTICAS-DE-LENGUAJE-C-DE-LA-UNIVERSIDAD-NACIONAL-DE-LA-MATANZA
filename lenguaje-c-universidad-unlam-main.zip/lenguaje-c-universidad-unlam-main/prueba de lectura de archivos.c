#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
typedef struct
{
char nombre[10];
int telefono;
}sContacto;
int main()
{
    sContacto contacto;

    FILE*arch;
    arch=fopen("agenda.dat","rb");
    if(arch==NULL)
    {
    printf("error al abrir el archivo");
    getch();
    exit(1);
    }
   
    fread(&contacto,sizeof(sContacto),1, arch);
   while(!feof(arch))
     {
    printf("\n%s\t%d", contacto.nombre, contacto.telefono);
    fread(&contacto,sizeof(sContacto),1, arch);
    }
    fclose(arch);
    getch();
    return 0;
}