#include<stdio.h>
#include<math.h>
int n1, n2, n3, resu;
int main()
{
    printf("ingrese tres numeros enteros, uno a la vez\n");
    printf("ingrese un numero:\n\n");
    scanf("%d", &n1);
    printf ("ingrese un numero:\n\n");
    scanf("%d", &n2);
    printf("ingrese un numero entero:\n\n");
    scanf("%d", &n3);
    if(n1<n2 && n1<n3)
    printf("el numero ingresado, el numero:%d es el mas chico",n1);
    if(n1>n2 && n1>n3)
    printf("el primer numero ingresado, el numero:%d no es el mas chico", n1);
   
    return 0;
}