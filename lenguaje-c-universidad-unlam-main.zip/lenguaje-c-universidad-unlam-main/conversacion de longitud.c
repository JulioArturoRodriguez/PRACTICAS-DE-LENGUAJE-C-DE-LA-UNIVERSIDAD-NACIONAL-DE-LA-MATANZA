#include<stdio.h>
#include<stdio.h>
float pie, pulgada, centimetros, yarda;
int main()
{
    printf("ingrese una medida en pies para mostrarla en otros valores:");
  
      scanf("%f", &pie);
    
    centimetros=pie*30.48;
    
    pulgada=pie*12.0;
    
    yarda=pie/3.0;
    
    printf("su medida en centimetros es:%f\n su medida en pulgada es:%f\n su medida en pie es:%f\n su medida en yarda es:%f\n",centimetros, pulgada, pie, yarda);
    return 0;
}