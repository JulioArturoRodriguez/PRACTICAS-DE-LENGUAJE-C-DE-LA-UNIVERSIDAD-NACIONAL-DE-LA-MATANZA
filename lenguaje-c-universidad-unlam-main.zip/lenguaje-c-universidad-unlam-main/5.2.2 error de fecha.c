#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main ()
{
int dia=0, mes=0, ano=0;
while (dia<35 && ano<2022 && mes<13)
{
if(dia<35 && ano<2022 && mes<13)
{
printf("ingrese dia:");
fflush(stdin);
scanf("%d", &dia);
}
if(dia<35 && ano<2022 && mes<13)
{
printf("ingrese mes:");
fflush(stdin);
scanf("%d", &mes);
}
if(dia<35 && ano<2022 && mes<13)
{
fflush(stdin);
printf("ingrese año");
scanf("%d", &ano);
}
{
if(dia<35 && ano<2022 && mes<13)
printf("%d\%d%\d", dia, mes, ano );
}
}
return 0;
}