#include<stdio.h>
#include<stdlib.h>
char intento[3][5];
int i, j;
int main()
{
    for(i=0;i<5;i++)
    for(j=0;j<3;j++)
    {
    printf("ingrese un numero entero:");
    scanf("%s", &intento);
    system("clear");
    }
    for(i=0;i<5;i++)
    {
    printf("\n fila\t");
    for(j=0;j<3;j++)
    {
    printf("%s\t", intento);
    }} 
    system("pause");
    
    return 0;
}