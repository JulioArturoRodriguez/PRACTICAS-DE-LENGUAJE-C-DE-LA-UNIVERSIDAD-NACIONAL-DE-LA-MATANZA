#include<stdio.h>
int intento[3][5];
int i, j;
int main()
{
    for(i=0;i<5;i++)
    for(j=0;j<3;j++)
    {
    printf("ingrese un numero entero[%d, %d]:", i, j);
    scanf("%d", &intento[i][j]);
    }
    for(i=0;i<5;i++)
    for(j=0;j<3;j++)
    {
    printf("\n numero:%d", intento[i][j]);
    }
    return 0;
}