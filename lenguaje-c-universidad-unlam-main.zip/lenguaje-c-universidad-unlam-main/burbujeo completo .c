#include<stdio.h>
#include<conio.h>
int i, j, aux;
int candele;
int vec[10];
int main()
{
for(i=0;i<10;i++)
{
printf("\n ingrese un numero entero %d:", i);
scanf("%d", &vec[i]);
}
candele=6;
   for(i=0;i<candele-1;i++){
   for(j=0;j<10;j++){
  if(vec[j]>vec[j+1]){
   aux=vec[j];
   vec[j]=vec[j+1];
   vec[j+1]=aux;
}
}
}
for(i=0;i<10;i++)
   printf("\n su numero es:%d", vec[i]);
    return 0;
}