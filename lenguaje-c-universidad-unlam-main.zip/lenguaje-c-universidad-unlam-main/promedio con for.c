#include<stdio.h>
int i, n1, suma=0, cont=0;
int main()
{
    for(i=1;i<=5;i++)
    {
    printf("ingrese un numero: \n");
    scanf("%d", &n1);
    suma+=n1;
    cont++;
    }
    printf("el promedio es:%d", (suma)/cont);
    return 0;
}