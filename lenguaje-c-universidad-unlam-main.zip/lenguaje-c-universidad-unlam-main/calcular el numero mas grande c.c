#include<stdio.h>
#include<math.h>
int n1, n2, n3, resu;
int main()
{
    printf("ingrese tres numeros enteros, uno a la vez\n");
    printf("ingrese un numero:\n\n");
    scanf("%d", &n1);
    printf ("ingrese un numero:\n\n");
    scanf("%d", &n2);
    printf("ingrese un numero entero:\n\n");
    scanf("%d", &n3);
    if(n1>n3&&n1>n2)
       resu=n1;
         if(n2>n1&& n2>n3)
            resu=n2;
              if(n1>n2&&n1>n3)
                 resu=n1;
                  if(n3>n1&&n3>n2)
                     resu=n3;
                      if(n3>n2&&n3>n1)
                         resu=n3;
                           if(n2>n3&&n2>n1)
                              resu=n2;
   printf("su numero mas grande es:%d",resu);
    return 0;
}