#include<stdio.h>
void cargarymostrar();
int main()
{
cargarymostrar();
return 0;
}
void cargarymostrar()
{
int vec[10];
int i;

    for(i=0; i<10; i++)
    {
    printf("\n ingrese el numero de la posicion:%d:", i);
    scanf("%d", &vec[i]);
}
for(i=0; i<10; i++)
{
printf("\n numero%d:%d", i, vec[i]);
}}
