#include<stdio.h>
int v[10];
void fun(a[]);
void imprimir (x[]);
int main()
{

   fun(v);
   imprimir(v);
    return 0;
}
void fun(int a[])
{
int i;
for(i=0;i<10;i++)
{
printf("introduce un valor%d:", i);
scanf("%d", &a[i]);
}
}
void imprimir(int x[])
{
int i;
for(i=0;i<10;i++)
printf("\n%d", x[i]);

}