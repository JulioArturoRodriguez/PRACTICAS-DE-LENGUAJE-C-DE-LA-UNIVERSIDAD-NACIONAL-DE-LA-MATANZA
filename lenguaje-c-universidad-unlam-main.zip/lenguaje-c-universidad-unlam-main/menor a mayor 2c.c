#include<stdio.h>
#include<math.h>
int n1, n2, n3;
int main()
{
    printf("ingrese un numero:");
    scanf("%d",&n1);
    printf("ingrese un segundo numero:");
    scanf("%d", &n2);
    printf("ingrese un tercer numero:");
    scanf("%d", &n3);
    
    if(n1<n2&&n1<n3)
    printf("el numero mas chico es:%d\n",n1);
       if(n2<n3&&n2<n1)
       printf("el numero mas chico es:%d\n", n2);
         if(n3<n1&&n3<n2)
          printf("el numero mas chico es:%d\n", n3);
    else

        if(n1>n2&&n1<n3)
        {
        printf("el numero intermedio es:%d\n", n1);
         }
         if(n2>n3&&n2<n1)
        {
         printf(" el numero intermedio es:%d\n", n2);
          }
           if(n3>n2&&n3<n2)
           {
           printf(" el numero intermedio es:%d\n", n3);
        }
    else 
    
    if(n1>n3&&n1>n2)
    {
    printf("el numero mas grande es:%d\n", n1);
    }
    if(n2>n1&&n2>n3)
    {
    printf("el numero mas grande es:%d\n", n2);
    }
    if(n3>n2&&n3>n1)
    {
    printf("el numero mas grande es:%d\n", n3);
    }
    else

    return 0;
}