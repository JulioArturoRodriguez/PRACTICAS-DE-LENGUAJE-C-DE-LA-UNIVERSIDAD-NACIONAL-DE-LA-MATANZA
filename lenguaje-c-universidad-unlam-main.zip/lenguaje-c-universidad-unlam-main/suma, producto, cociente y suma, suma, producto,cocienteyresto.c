#include<stdio.h>
int n1, n2, suma, resto, producto, cociente;

int main()
{
    printf("ingrese un numero, mas tarde se le pedira otro, de este y el segundo se le informara, la suma, el cociente, el resto y el producto: ");
   scanf("%d", &n1);
    printf("ingrese otro número:");
    scanf("%d", &n2);
    suma=n1+n2;
    resto=n1%n2;
    producto=n1+n2;
    cociente=n1/n2;
    printf("su suma es:%d\n su resto es:%d\n su producto es:%d\n su cociente es:%d", suma, resto, producto, cociente);
    
     return 0;
}