#include<stdio.h>
int i, vec[10];
int main()
{
    for(i=0; i<10; i++)
    {
    printf("\n ingrese el numero de la posicion:%i:", i);
    scanf("%i", &vec[i]);
    }
    for(i=0; i<10; i++)
    
    printf("\n numero posicion %i: %i", i,vec[i]);
    
    return 0;
}