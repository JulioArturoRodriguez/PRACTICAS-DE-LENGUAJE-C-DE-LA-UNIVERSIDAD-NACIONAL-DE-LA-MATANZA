#include<stdio.h>
int num;
int i;
int main()
{
    do{
    printf("\n ingrese un numero entero:");
    scanf("%d", &num);
    }while(num<10);
    return 0;
}