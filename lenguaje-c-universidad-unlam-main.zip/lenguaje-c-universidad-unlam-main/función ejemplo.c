#include<stdio.h>
int main()
{
int suma;
suma=sumardosnumerosenteros(suma);
printf("la suma con retorno de los números es: %d", suma);

return 0;
}
int sumardosnumerosenteros(int s)
{
int num1, num2;
printf(" ingrese un numero:\n");
scanf("%d", &num1);
printf("ingrese el numero:\n");
scanf("%d", &num2);
s=num1+num2;
return s;
}