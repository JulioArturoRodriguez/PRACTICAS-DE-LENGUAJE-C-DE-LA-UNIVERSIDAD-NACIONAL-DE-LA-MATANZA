#include <stdio.h>
#include <stdlib.h>
 
int main()
{
    int cont_mult5=0, suma_pares=0, suma_mult3=0;
    int num, N, i;
 
    printf("\nIngrese N: ");
    scanf("%d", &N);
 
    for(i=1;i<=N;i++)
    {
        printf("\nIngrese un numero: ");
        scanf("%d", &num);
 
        if(num%3==0) suma_mult3+=num;
        else;
        if(num%5==0) cont_mult5++;
        else;
        if(i%2==0) suma_pares+=num;
        else;
    }
 
    printf("\n\nLa suma de los multiplos de 3 es: %d", suma_mult3);
    printf("\nLa cantidad de multiplos de 5 es: %d", cont_mult5);
    printf("\nLa suma de los numeros ingresados en posiciones pares es de: %d", suma_pares);
 
 
    return 0;
}
 