#include<stdio.h>
int n1, n2, promedio;

int main()
{
   printf("ingrese un número:");
   scanf("%d", &n1);
   printf("ingrese otro numero:");
   scanf("%d", &n2);
   promedio=(n1+n2)/2;
   printf("su promedio es:%d", promedio);
   return 0;
}