 
#include <stdio.h> 
int main() {    
 int vector[10];    
 int i; 
   
for(i=0; i<=9; i++) 
    { 
       
       printf("\nIngrese un numero real: ");       
      scanf("%d", &vector[i]); 
    } 

      printf("\n Contenido del array\n");   
      for(i=0; i<=9; i++) 
    { 
        printf("%d\n", vector[i]); 
    } 
} 
    