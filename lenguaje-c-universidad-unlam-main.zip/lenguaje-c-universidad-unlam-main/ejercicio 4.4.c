#include<stdio.h>
#include<math.h>
int n1, n2, n3;
int main()
{
    printf("ingrese tres numeros enteros, uno a la vez\n");
    printf("ingrese un numero:\n\n");
    scanf("%d", &n1);
    printf ("ingrese un numero:\n\n");
    scanf("%d", &n2);
    printf("ingrese un numero entero:\n\n");
    scanf("%d", &n3);
   if(n1==n2&&n1==n3)
      {
     printf("los tres numeros son iguales");
       }
      if(n1>n2&&n2>n3)
        {
        printf("el primer numero es mayor que los otros");
        }
         if(n2>n1&&n1>n3)
          {
         printf("el segundo numero es mayor que los otros");
            }
            if(n1<n2&&n1<n3)
            printf("el primer numero es mas menor que los otros");
               if(n2<n1&&n2<n3)
                printf("el segundo numero es menor que los otros");
return 0;
}