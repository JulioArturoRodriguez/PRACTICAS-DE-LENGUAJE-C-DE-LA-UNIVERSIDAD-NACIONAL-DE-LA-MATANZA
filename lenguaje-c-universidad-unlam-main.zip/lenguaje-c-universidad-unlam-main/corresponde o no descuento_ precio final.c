#include<stdio.h>
#include<math.h>

int main()

{
int n1, n2, resu;
    printf("ingrese el precio:\n");
    scanf("%d", &n1);
    printf("ingrese opción 0 si no tiene descuento y 1 si tiene descuento:\n\n");
    scanf("%d", &n2);
    if(n2>0)
    {
    resu=(n1*80/100);
    }
    else
      {
    resu=n1;
       }
      printf("su precio es:%d", resu);
    return 0;
}