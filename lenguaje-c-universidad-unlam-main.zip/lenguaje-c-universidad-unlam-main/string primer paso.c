#include<stdio.h>
#include<stdlib.h>
char intento[5];
int main()
{
    printf("ingrese un numero entero:");
    scanf("%s", intento);
    system("clear");
    printf("%s\t", intento);
    return 0;
}