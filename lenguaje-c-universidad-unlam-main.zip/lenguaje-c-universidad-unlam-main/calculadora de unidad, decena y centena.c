#include<stdio.h>
int n1, unidad, decena, centena;
int main()
{
    printf("ingrese un numero entero para descomponerlo en unidad, decena y centena:\n");
    scanf("%d", &n1);
    unidad=n1/1;
    decena=n1/10;
    centena=n1/100;
    printf("unidad:%d \n decena:%d \n centena:%d \n", unidad, decena, centena);
     return 0;
}